"""
02_visualizations.py
---------------------
Builds 8 charts from the cleaned IPL data and saves each as a PNG in
output/charts/. Each chart is paired with a one-line business insight;
the INSIGHTS dict at the bottom is reused by 03_build_report.py when
assembling the final PDF report.

Run from the project root:
    python scripts/02_visualizations.py
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CLEAN_DIR = ROOT / "output" / "cleaned"
CHART_DIR = ROOT / "output" / "charts"
CHART_DIR.mkdir(parents=True, exist_ok=True)

sns.set_theme(style="whitegrid", palette="viridis")
plt.rcParams.update({
    "figure.dpi": 120,
    "savefig.dpi": 150,
    "font.size": 11,
    "axes.titlesize": 15,
    "axes.titleweight": "bold",
    "axes.labelsize": 12,
})

matches = pd.read_csv(CLEAN_DIR / "matches_cleaned.csv", parse_dates=["date"])
deliveries = pd.read_csv(CLEAN_DIR / "deliveries_cleaned.csv")

# Order in which charts are produced AND will appear in the PDF report.
INSIGHTS = {}


def save(fig, name):
    path = CHART_DIR / f"{name}.png"
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"saved {path.name}")


# ---------------------------------------------------------------
# 1. Matches played per season
# ---------------------------------------------------------------
season_counts = matches.groupby("season").size()
fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(season_counts.index.astype(str), season_counts.values, color=sns.color_palette("viridis", len(season_counts)))
ax.set_title("IPL Matches Played per Season (2008-2017)")
ax.set_xlabel("Season")
ax.set_ylabel("Number of Matches")
for i, v in enumerate(season_counts.values):
    ax.text(i, v + 1, str(v), ha="center", fontsize=9)
save(fig, "01_matches_per_season")
INSIGHTS["01_matches_per_season"] = (
    "Match volume spiked to 73-76 games in 2011-2013 when the league briefly expanded to "
    "9-10 franchises, then settled back to roughly 59-60 matches/season once it stabilized "
    "at 8 teams from 2014 onward -- showing franchise count, not fan demand, was the main "
    "driver of season length."
)

# ---------------------------------------------------------------
# 2. Team win percentage (teams with 30+ matches played, to keep it fair)
# ---------------------------------------------------------------
played = pd.concat([matches["team1"], matches["team2"]]).value_counts()
wins = matches[matches["winner"] != "No Result"]["winner"].value_counts()
win_pct = (wins / played * 100).dropna()
win_pct = win_pct[played >= 30].sort_values(ascending=False)

fig, ax = plt.subplots(figsize=(9, 6))
colors = sns.color_palette("viridis", len(win_pct))
bars = ax.barh(win_pct.index[::-1], win_pct.values[::-1], color=colors[::-1])
ax.set_title("Team Win Percentage (Teams with 30+ Matches Played)")
ax.set_xlabel("Win Percentage (%)")
ax.set_ylabel("Team")
for bar, val in zip(bars, win_pct.values[::-1]):
    ax.text(val + 0.5, bar.get_y() + bar.get_height() / 2, f"{val:.1f}%", va="center", fontsize=9)
save(fig, "02_team_win_percentage")
top_team = win_pct.index[0]
INSIGHTS["02_team_win_percentage"] = (
    f"{top_team} has the highest win rate among established franchises at {win_pct.iloc[0]:.1f}%, "
    "consistent, sustained success rather than a single strong season is what separates the top "
    "of the table from mid-table teams."
)

# ---------------------------------------------------------------
# 3. Toss decision trend over seasons (bat vs field)
# ---------------------------------------------------------------
toss_trend = matches.groupby(["season", "toss_decision"]).size().unstack(fill_value=0)
toss_pct = toss_trend.div(toss_trend.sum(axis=1), axis=0) * 100

fig, ax = plt.subplots(figsize=(9, 5))
ax.plot(toss_pct.index, toss_pct["field"], marker="o", linewidth=2.5, label="Chose to Field First", color="#21918c")
ax.plot(toss_pct.index, toss_pct["bat"], marker="o", linewidth=2.5, label="Chose to Bat First", color="#fde725")
ax.set_title("Toss Decision Trend: Bat First vs Field First")
ax.set_xlabel("Season")
ax.set_ylabel("Share of Toss-Winning Decisions (%)")
ax.legend(title="Decision")
save(fig, "03_toss_decision_trend")
INSIGHTS["03_toss_decision_trend"] = (
    "Through 2008-2013 the bat-first vs field-first split swung back and forth season to "
    "season with no clear pattern, but from 2014 onward fielding first became the dominant "
    "choice, reaching roughly 82% of toss-winning decisions by 2016-2017 -- a clear "
    "league-wide tactical shift toward chasing under lights as the format matured."
)

# ---------------------------------------------------------------
# 4. Does winning the toss help win the match?
# ---------------------------------------------------------------
decided = matches[matches["winner"] != "No Result"].copy()
decided["toss_match_same"] = decided["toss_winner"] == decided["winner"]
toss_effect = decided["toss_match_same"].value_counts(normalize=True) * 100

fig, ax = plt.subplots(figsize=(6.5, 6.5))
labels = ["Toss Winner Won Match", "Toss Winner Lost Match"]
values = [toss_effect.get(True, 0), toss_effect.get(False, 0)]
ax.pie(values, labels=labels, autopct="%1.1f%%", startangle=90,
       colors=["#21918c", "#440154"], textprops={"fontsize": 11},
       wedgeprops={"edgecolor": "white", "linewidth": 1.5})
ax.set_title("Does Winning the Toss Predict Winning the Match?")
save(fig, "04_toss_advantage")
INSIGHTS["04_toss_advantage"] = (
    f"Winning the toss translated into winning the match only {values[0]:.1f}% of the time -- "
    "barely better than a coin flip -- so while the toss-then-field trend (chart 3) shows "
    "teams clearly believe it matters, the data says toss is a marginal factor at best "
    "compared to actual team quality."
)

# ---------------------------------------------------------------
# 5. Top 10 run scorers
# ---------------------------------------------------------------
top_scorers = deliveries.groupby("batsman")["batsman_runs"].sum().sort_values(ascending=False).head(10)
fig, ax = plt.subplots(figsize=(9, 6))
bars = ax.barh(top_scorers.index[::-1], top_scorers.values[::-1], color=sns.color_palette("viridis", 10)[::-1])
ax.set_title("Top 10 Run Scorers, 2008-2017")
ax.set_xlabel("Total Runs")
ax.set_ylabel("Batsman")
for bar, val in zip(bars, top_scorers.values[::-1]):
    ax.text(val + 30, bar.get_y() + bar.get_height() / 2, f"{val:,}", va="center", fontsize=9)
save(fig, "05_top_run_scorers")
INSIGHTS["05_top_run_scorers"] = (
    f"{top_scorers.index[0]} leads all batsmen with {top_scorers.iloc[0]:,} runs across the "
    "decade, and the top 10 is dominated by top-order batsmen who played nearly every season -- "
    "run-scoring at the top of this list is driven by longevity and consistency, not single "
    "standout seasons."
)

# ---------------------------------------------------------------
# 6. Top 10 wicket takers
# ---------------------------------------------------------------
wickets = deliveries[deliveries["dismissal_kind"].isin(
    ["caught", "bowled", "lbw", "caught and bowled", "stumped", "hit wicket"]
)]
top_wickets = wickets.groupby("bowler").size().sort_values(ascending=False).head(10)
fig, ax = plt.subplots(figsize=(9, 6))
bars = ax.barh(top_wickets.index[::-1], top_wickets.values[::-1], color=sns.color_palette("magma", 10)[::-1])
ax.set_title("Top 10 Wicket Takers, 2008-2017")
ax.set_xlabel("Wickets Taken")
ax.set_ylabel("Bowler")
for bar, val in zip(bars, top_wickets.values[::-1]):
    ax.text(val + 1.5, bar.get_y() + bar.get_height() / 2, str(val), va="center", fontsize=9)
save(fig, "06_top_wicket_takers")
INSIGHTS["06_top_wicket_takers"] = (
    f"{top_wickets.index[0]} tops the wicket-takers list with {top_wickets.iloc[0]} wickets, "
    "well clear of the rest of the pack; the next nine are tightly bunched between 100-134 "
    "wickets, showing that beyond the single standout performer, wicket-taking success is "
    "spread fairly evenly across a deep pool of frontline bowlers."
)

# ---------------------------------------------------------------
# 7. Average runs per match by season (scoring trend)
# ---------------------------------------------------------------
match_totals = deliveries.groupby("match_id")["total_runs"].sum()
match_season = matches.set_index("id")["season"]
runs_per_season = match_totals.groupby(match_season).mean()

fig, ax = plt.subplots(figsize=(9, 5))
ax.plot(runs_per_season.index, runs_per_season.values, marker="o", linewidth=2.5, color="#fde725")
ax.fill_between(runs_per_season.index, runs_per_season.values, alpha=0.15, color="#fde725")
ax.set_title("Average Total Runs per Match, by Season")
ax.set_xlabel("Season")
ax.set_ylabel("Avg. Runs per Match (Both Innings)")
save(fig, "07_avg_runs_per_season")
INSIGHTS["07_avg_runs_per_season"] = (
    "After dipping to its lowest points in 2009 and 2011 (under 290 runs/match), scoring "
    "climbed steadily from 2012 onward and has stayed above 310 runs/match every season "
    "since 2014 -- a sustained, league-wide rise in scoring intensity rather than a single "
    "high-scoring season skewing the average."
)

# ---------------------------------------------------------------
# 8. Most Player-of-the-Match awards (consistency indicator)
# ---------------------------------------------------------------
potm = matches[matches["player_of_match"] != "N/A"]["player_of_match"].value_counts().head(10)
fig, ax = plt.subplots(figsize=(9, 6))
bars = ax.barh(potm.index[::-1], potm.values[::-1], color=sns.color_palette("crest", 10)[::-1])
ax.set_title("Top 10 Players by Player-of-the-Match Awards")
ax.set_xlabel("Awards Won")
ax.set_ylabel("Player")
for bar, val in zip(bars, potm.values[::-1]):
    ax.text(val + 0.3, bar.get_y() + bar.get_height() / 2, str(val), va="center", fontsize=9)
save(fig, "08_player_of_match_awards")
INSIGHTS["08_player_of_match_awards"] = (
    f"{potm.index[0]} has earned the most Player-of-the-Match awards ({potm.iloc[0]}), and most "
    "names on this list also appear among the top run-scorers or wicket-takers -- match-winning "
    "impact in the IPL is concentrated in a small core of repeat performers rather than spread "
    "evenly across the player pool."
)

# Save insights so the report-builder script doesn't need to recompute anything
import json
with open(CHART_DIR / "insights.json", "w") as f:
    json.dump(INSIGHTS, f, indent=2)

print(f"\nGenerated {len(INSIGHTS)} charts + insights.json in {CHART_DIR}")
