"""
01_data_cleaning.py
--------------------
Loads the raw IPL match-level and ball-by-ball datasets, fixes missing
values and inconsistent entries, and writes cleaned CSVs to output/cleaned/.

Dataset: IPL ball-by-ball + match data, 2008-2017 seasons (636 matches,
150,460 deliveries). Source: Kaggle "IPL Complete Dataset" (manasgarg/ipl).

Run from the project root:
    python scripts/01_data_cleaning.py
"""

import pandas as pd
from pathlib import Path

RAW_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"
OUT_DIR = Path(__file__).resolve().parent.parent / "output" / "cleaned"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# A few team names are spelled two different ways across the raw files
# (e.g. "Rising Pune Supergiant" vs "Rising Pune Supergiants"). We
# standardize on a single, correct spelling for every team so that
# group-bys and joins don't silently split one team into two rows.
TEAM_NAME_FIX = {
    "Rising Pune Supergiant": "Rising Pune Supergiants",
}

TEAM_COLUMNS_MATCHES = ["team1", "team2", "toss_winner", "winner"]
TEAM_COLUMNS_DELIVERIES = ["batting_team", "bowling_team"]


def clean_matches(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    before_rows = len(df)

    # --- standardize text columns ---
    for col in df.select_dtypes(include=["object", "str"]).columns:
        df[col] = df[col].str.strip()

    for col in TEAM_COLUMNS_MATCHES:
        df[col] = df[col].replace(TEAM_NAME_FIX)

    # --- fix missing city: every missing city belongs to a match played
    # in Dubai (venue = "Dubai International Cricket Stadium") ---
    dubai_mask = df["venue"].str.contains("Dubai", na=False)
    df.loc[df["city"].isna() & dubai_mask, "city"] = "Dubai"
    # catch-all for any other missing city: fall back to venue text
    df["city"] = df["city"].fillna(df["venue"])

    # --- matches with no winner are genuine "no result" games (washed
    # out / abandoned), not bad data, so we label them explicitly
    # instead of leaving NaN or silently dropping rows ---
    df["winner"] = df["winner"].fillna("No Result")
    df["player_of_match"] = df["player_of_match"].fillna("N/A")

    # --- umpire3 is empty for every single match (third umpire wasn't
    # recorded in this dataset) -> drop, it carries no information ---
    df = df.drop(columns=["umpire3"])
    df["umpire1"] = df["umpire1"].fillna("Unknown")
    df["umpire2"] = df["umpire2"].fillna("Unknown")

    # --- correct dtypes ---
    df["date"] = pd.to_datetime(df["date"])
    df["dl_applied"] = df["dl_applied"].astype(bool)

    after_na = df.isna().sum().sum()
    print(f"[matches]   rows: {before_rows} -> {len(df)} | remaining NaNs: {after_na}")
    return df


def clean_deliveries(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    before_rows = len(df)

    for col in TEAM_COLUMNS_DELIVERIES:
        df[col] = df[col].str.strip().replace(TEAM_NAME_FIX)

    # one exact duplicate ball recorded twice -> drop it
    dup_count = df.duplicated().sum()
    df = df.drop_duplicates()

    # player_dismissed / dismissal_kind / fielder are NaN on the ~95% of
    # balls where no wicket fell. That's expected structure, not missing
    # data -- we make it explicit rather than leaving ambiguous NaNs.
    df["player_dismissed"] = df["player_dismissed"].fillna("Not Out")
    df["dismissal_kind"] = df["dismissal_kind"].fillna("Not Out")
    df["fielder"] = df["fielder"].fillna("N/A")

    # sanity check: total_runs should equal batsman_runs + extra_runs
    bad_runs = (df["batsman_runs"] + df["extra_runs"] != df["total_runs"]).sum()

    after_na = df[["match_id", "inning", "batting_team", "bowling_team",
                   "batsman", "bowler", "total_runs"]].isna().sum().sum()
    print(f"[deliveries] rows: {before_rows} -> {len(df)} | duplicates removed: {dup_count} "
          f"| run-total mismatches: {bad_runs} | core-column NaNs: {after_na}")
    return df


def main():
    matches = clean_matches(RAW_DIR / "matches.csv")
    deliveries = clean_deliveries(RAW_DIR / "deliveries.csv")

    matches.to_csv(OUT_DIR / "matches_cleaned.csv", index=False)
    deliveries.to_csv(OUT_DIR / "deliveries_cleaned.csv", index=False)
    print(f"\nSaved cleaned files to {OUT_DIR}")


if __name__ == "__main__":
    main()
