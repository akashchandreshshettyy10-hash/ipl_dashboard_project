"""
03_build_report.py
--------------------
Assembles the cleaned-data summary, all 8 charts, and their insight text
into a single PDF report: output/report/IPL_Insights_Report.pdf

Run from the project root:
    python scripts/03_build_report.py
"""

import json
from pathlib import Path
from datetime import date

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle
)

ROOT = Path(__file__).resolve().parent.parent
CHART_DIR = ROOT / "output" / "charts"
REPORT_PATH = ROOT / "output" / "report" / "IPL_Insights_Report.pdf"

with open(CHART_DIR / "insights.json") as f:
    INSIGHTS = json.load(f)

CHART_TITLES = {
    "01_matches_per_season": "1. Matches Played per Season",
    "02_team_win_percentage": "2. Team Win Percentage",
    "03_toss_decision_trend": "3. Toss Decision Trend Over Time",
    "04_toss_advantage": "4. Toss Advantage on Match Outcome",
    "05_top_run_scorers": "5. Top 10 Run Scorers",
    "06_top_wicket_takers": "6. Top 10 Wicket Takers",
    "07_avg_runs_per_season": "7. Scoring Trend Across Seasons",
    "08_player_of_match_awards": "8. Most Player-of-the-Match Awards",
}

styles = getSampleStyleSheet()
title_style = ParagraphStyle("TitlePage", parent=styles["Title"], fontSize=28, spaceAfter=10)
subtitle_style = ParagraphStyle("Subtitle", parent=styles["Normal"], fontSize=14,
                                 alignment=TA_CENTER, textColor=colors.HexColor("#444444"))
chart_heading_style = ParagraphStyle("ChartHeading", parent=styles["Heading2"],
                                      fontSize=15, spaceBefore=4, spaceAfter=8,
                                      textColor=colors.HexColor("#21918c"))
insight_label_style = ParagraphStyle("InsightLabel", parent=styles["Normal"],
                                      fontSize=10, textColor=colors.HexColor("#888888"),
                                      spaceBefore=10)
insight_style = ParagraphStyle("Insight", parent=styles["Normal"], fontSize=11.5,
                                leading=16, textColor=colors.HexColor("#222222"))
section_style = ParagraphStyle("Section", parent=styles["Heading1"], fontSize=18,
                                textColor=colors.HexColor("#21918c"), spaceAfter=12)

story = []

# ---------------- Title page ----------------
story.append(Spacer(1, 1.6 * inch))
story.append(Paragraph("IPL Performance & Insights Dashboard", title_style))
story.append(Spacer(1, 0.15 * inch))
story.append(Paragraph("A Data-Driven Story of the Indian Premier League, 2008-2017", subtitle_style))
story.append(Spacer(1, 0.4 * inch))
story.append(Paragraph(f"Generated {date.today().strftime('%B %d, %Y')}", subtitle_style))
story.append(Spacer(1, 1 * inch))

summary_data = [
    ["Dataset", "636 matches, 150,459 deliveries"],
    ["Seasons covered", "2008 - 2017 (10 seasons)"],
    ["Tools used", "Python, Pandas, Matplotlib, Seaborn"],
    ["Charts in this report", "8"],
]
tbl = Table(summary_data, colWidths=[2.2 * inch, 3.3 * inch])
tbl.setStyle(TableStyle([
    ("FONTSIZE", (0, 0), (-1, -1), 11),
    ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#21918c")),
    ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ("TOPPADDING", (0, 0), (-1, -1), 8),
    ("LINEBELOW", (0, 0), (-1, -2), 0.5, colors.HexColor("#dddddd")),
]))
story.append(tbl)
story.append(PageBreak())

# ---------------- Methodology / cleaning summary ----------------
story.append(Paragraph("Data Cleaning Summary", section_style))
cleaning_points = [
    "Standardized inconsistent team names (e.g. \"Rising Pune Supergiant\" vs "
    "\"Rising Pune Supergiants\" merged into one spelling) across both files.",
    "Filled 7 missing city values for matches played in Dubai using the venue field.",
    "Labeled 3 matches with no winner as \"No Result\" (rain-affected / abandoned games) "
    "instead of leaving them as null or dropping them.",
    "Dropped the umpire3 column, which was empty for all 636 matches.",
    "Removed 1 exact duplicate row from the ball-by-ball deliveries data.",
    "Made dismissal-related fields explicit (\"Not Out\") instead of ambiguous NaNs for "
    "the ~95% of deliveries where no wicket fell.",
    "Validated that batsman_runs + extra_runs = total_runs for every delivery (0 mismatches found).",
]
for point in cleaning_points:
    story.append(Paragraph(f"&bull;&nbsp;&nbsp;{point}", insight_style))
    story.append(Spacer(1, 6))
story.append(PageBreak())

# ---------------- Charts + insights ----------------
for key, heading in CHART_TITLES.items():
    img_path = CHART_DIR / f"{key}.png"
    story.append(Paragraph(heading, chart_heading_style))
    story.append(Image(str(img_path), width=6.3 * inch, height=6.3 * inch * (5/9)))
    story.append(Paragraph("BUSINESS INSIGHT", insight_label_style))
    story.append(Paragraph(INSIGHTS[key], insight_style))
    story.append(PageBreak())

# ---------------- Closing summary ----------------
story.append(Paragraph("Key Takeaways", section_style))
takeaways = [
    "Team success is sustained, not streaky: Chennai Super Kings and Mumbai Indians lead "
    "the win-percentage table through consistent performance across many seasons, not one outlier year.",
    "The toss matters far less than teams act like it does: winning the toss predicts the "
    "match outcome barely better than a coin flip, even as fielding-first became the dominant strategy.",
    "Scoring has intensified league-wide since 2014, reflecting more aggressive batting approaches "
    "as T20 strategy matured.",
    "Match-winning impact concentrates in a small core of repeat performers: the same names "
    "(Gayle, Raina, Kohli, Warner) recur across the run-scoring, wicket-taking, and Player-of-the-Match lists.",
]
for t in takeaways:
    story.append(Paragraph(f"&bull;&nbsp;&nbsp;{t}", insight_style))
    story.append(Spacer(1, 8))

doc = SimpleDocTemplate(
    str(REPORT_PATH), pagesize=letter,
    topMargin=0.7 * inch, bottomMargin=0.7 * inch,
    leftMargin=0.8 * inch, rightMargin=0.8 * inch,
)
doc.build(story)
print(f"Report saved to {REPORT_PATH}")
