# IPL Performance & Insights Dashboard

A complete data cleaning + visual storytelling project built on a real IPL
(Indian Premier League) cricket dataset, covering 636 matches and 150,459
ball-by-ball deliveries from the 2008-2017 seasons.

## Project Structure

```
ipl_dashboard/
├── data/
│   └── raw/                    matches.csv, deliveries.csv (original data)
├── scripts/
│   ├── 01_data_cleaning.py     loads + cleans both datasets
│   ├── 02_visualizations.py    generates 8 charts + insight text
│   └── 03_build_report.py      assembles everything into a PDF report
├── output/
│   ├── cleaned/                cleaned CSVs (output of step 1)
│   ├── charts/                 8 PNG charts + insights.json (output of step 2)
│   └── report/
│       └── IPL_Insights_Report.pdf   <- final deliverable (output of step 3)
└── requirements.txt
```

## How to Run

```bash
pip install -r requirements.txt
python scripts/01_data_cleaning.py
python scripts/02_visualizations.py
python scripts/03_build_report.py
```

Each script reads the previous step's output, so run them in order. The
final PDF report lands at `output/report/IPL_Insights_Report.pdf`.

## What Was Cleaned

- Merged inconsistent team name spellings ("Rising Pune Supergiant" /
  "Rising Pune Supergiants") into one consistent name.
- Filled missing `city` values for Dubai-hosted matches using the venue field.
- Labeled matches with no winner as "No Result" instead of leaving NaN.
- Dropped the fully-empty `umpire3` column.
- Removed 1 exact duplicate row in the ball-by-ball data.
- Made dismissal-related fields explicit ("Not Out") instead of ambiguous NaNs.
- Validated `batsman_runs + extra_runs = total_runs` for every delivery.

## The 8 Charts

1. Matches played per season
2. Team win percentage (teams with 30+ matches)
3. Toss decision trend (bat first vs field first) over time
4. Does winning the toss predict winning the match?
5. Top 10 run scorers
6. Top 10 wicket takers
7. Average runs per match by season (scoring trend)
8. Most Player-of-the-Match awards

Each chart in the PDF report is followed directly by a one-paragraph
business insight describing the pattern shown.

## Dataset Source

IPL ball-by-ball + match-level data, originally published on Kaggle
("IPL Complete Dataset", manasgarg/ipl), 2008-2017 seasons.
